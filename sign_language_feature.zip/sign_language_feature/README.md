# 🤟 Sign Language Interpreter for VisionAssist Smart Glasses

A production-grade Sign-to-Voice Communication Mode that enables blind users to understand sign language through real-time audio feedback.

## Features

### Core Capabilities
- **Real-time ASL Recognition**: Recognizes American Sign Language in real-time using MediaPipe hand tracking
- **Fingerspelling Support**: Full A-Z alphabet and 0-9 number recognition
- **50+ Common Signs**: Includes greetings, questions, common words, and phrases
- **Text-to-Speech Output**: Speaks recognized signs aloud for blind users
- **Confidence-based Feedback**: Uses uncertainty prompts when recognition is unclear ("I'm not sure, can you repeat slower?")

### Technical Features
- **Temporal Pattern Analysis**: Detects dynamic signs requiring motion (J, Z, waving)
- **Kalman Filtering**: Smooth landmark tracking for stable recognition
- **Multi-hand Support**: Tracks both hands for two-handed signs
- **Word Building**: Accumulates fingerspelled letters into words
- **Adaptive Thresholds**: Configurable confidence levels for different use cases

## Installation

### 1. Copy the Files

Copy these files to your project:

```
src/
├── ai_features/
│   ├── sign_language_interpreter.py  # Main interpreter module
│   ├── sign_language_integration.py  # Integration guide
│   └── __init__.py                   # Updated (use __init__updated.py)
└── utils/
    └── config_sign_language.py       # Configuration options
```

### 2. Install Dependencies

The Sign Language Interpreter uses MediaPipe for hand tracking. It should already be installed if you have the Human Analyzer working:

```bash
pip install mediapipe>=0.10.0
```

### 3. Update __init__.py

Replace your `src/ai_features/__init__.py` with the updated version (`__init__updated.py`), or manually add these imports:

```python
from .sign_language_interpreter import (
    SignLanguageInterpreter,
    SignCategory,
    SignConfidence,
    InterpreterMode,
    RecognizedSign,
    SignSequence,
    HandLandmarks,
    create_sign_interpreter,
)
```

### 4. Add Configuration (Optional)

Append the contents of `config_sign_language.py` to your `src/utils/config.py` for customizable settings.

### 5. Integrate with Controller

Follow the integration guide in `sign_language_integration.py` or run:

```bash
python src/ai_features/sign_language_integration.py
```

## Quick Integration

Add these key changes to your `controller.py`:

### Import
```python
from src.ai_features.sign_language_interpreter import create_sign_interpreter
```

### Initialize (in `__init__`)
```python
self.sign_interpreter = create_sign_interpreter(
    mode="continuous",
    speech_callback=self._speak_sign_callback,
)
self._sign_mode_enabled = False
```

### Add Callback Method
```python
def _speak_sign_callback(self, text: str) -> None:
    if text:
        threading.Thread(
            target=lambda: self._speak_blocking(text, meta={"source": "sign_interpreter"}),
            daemon=True
        ).start()
```

### Add Key Handler (in main loop)
```python
elif key == ord("g"):
    self._sign_mode_enabled = not self._sign_mode_enabled
    state = "ON" if self._sign_mode_enabled else "OFF"
    self._speak_blocking(f"Sign language interpreter {state.lower()}.")
```

### Process Signs (in main loop)
```python
if self._sign_mode_enabled and self.sign_interpreter:
    signs, annotated_frame = self.sign_interpreter.process_frame(annotated_frame, detections)
```

## Usage

### Keyboard Controls
- **'g'** - Toggle sign language interpreter mode ON/OFF

### Operating Modes
- **Continuous** (default): Recognizes both fingerspelling and word signs
- **Fingerspelling**: Letter-by-letter recognition only
- **Word Signs**: Common signs and phrases only

### Recognition Tips
1. Hold signs steady for at least 200ms
2. Keep hands clearly visible in the camera frame
3. Good lighting significantly improves accuracy
4. For fingerspelling, pause briefly between letters
5. A 1-second pause will trigger word completion

## Supported Signs

### Alphabet (A-Z)
All 26 ASL alphabet letters with disambiguation for similar signs (A/S, M/N, etc.)

### Numbers (0-9)
All numeric signs

### Common Words & Phrases

| Category | Signs |
|----------|-------|
| **Greetings** | hello, goodbye, please, thank you, sorry |
| **Responses** | yes, no |
| **Questions** | what, where, who, when, why, how |
| **Actions** | help, stop, wait, again |
| **Requests** | more, want, need, like |
| **Communication** | sign, speak, listen, repeat, understand, don't understand |
| **Descriptions** | good, bad, big, small, slow, fast |
| **Emergency** | emergency, danger |

## API Reference

### create_sign_interpreter()

Factory function to create a configured interpreter:

```python
interpreter = create_sign_interpreter(
    mode="continuous",           # "fingerspelling", "word_signs", "continuous"
    speech_callback=my_speak,    # Function to call for TTS
    min_detection_confidence=0.7,
    min_tracking_confidence=0.5,
    speak_letters=True,          # Speak individual letters
    speak_words=True,            # Speak completed words
    enable_visual_feedback=True, # Draw overlays on frame
)
```

### SignLanguageInterpreter Methods

```python
# Process a frame
signs, annotated_frame = interpreter.process_frame(frame)

# Get current word being spelled
word = interpreter.get_current_word()

# Clear the letter buffer
interpreter.clear_buffer()

# Change operating mode
interpreter.set_mode(InterpreterMode.FINGERSPELLING)

# Get speech description
description = interpreter.describe_for_speech(signs, frame_width)

# Request signer to repeat
interpreter.request_repeat()
```

## Configuration Options

Add to your `.env` file or export as environment variables:

```bash
# Enable/disable feature
SIGN_LANGUAGE_ENABLED=1

# Operating mode
SIGN_LANGUAGE_MODE=continuous

# Detection thresholds
SIGN_DETECTION_CONFIDENCE=0.7
SIGN_TRACKING_CONFIDENCE=0.5
SIGN_CONFIRMATION_THRESHOLD=0.75
SIGN_UNCERTAIN_THRESHOLD=0.55

# Speech settings
SIGN_SPEAK_LETTERS=1
SIGN_SPEAK_WORDS=1
SIGN_WORD_PAUSE_THRESHOLD=1.0
SIGN_MIN_LETTER_INTERVAL=0.5

# Recognition timing
SIGN_MIN_HOLD_TIME=0.15
SIGN_STABILITY_FRAMES=3

# Visual feedback
SIGN_VISUAL_FEEDBACK=1
```

## Standalone Testing

Test the interpreter directly:

```bash
python src/ai_features/sign_language_interpreter.py
```

Controls:
- **'q'** - Quit
- **'c'** - Clear buffer
- **'1'** - Fingerspelling mode
- **'2'** - Word signs mode
- **'3'** - Continuous mode

## Future Enhancements

Planned improvements:
- [ ] WLASL dataset integration for expanded vocabulary
- [ ] Dynamic sign recognition improvements
- [ ] Sentence-level grammar correction
- [ ] Regional sign language variants (BSL, etc.)
- [ ] Sign language teaching mode
- [ ] Custom vocabulary training

## Troubleshooting

### "MediaPipe not found"
```bash
pip install mediapipe --upgrade
```

### Poor recognition accuracy
- Ensure good lighting
- Keep hands within camera frame
- Try adjusting `SIGN_DETECTION_CONFIDENCE` lower

### Signs not being spoken
- Check that `speech_callback` is properly configured
- Verify `SIGN_SPEAK_LETTERS` and `SIGN_SPEAK_WORDS` are enabled

### High latency
- Reduce frame resolution
- Adjust `PROCESS_EVERY_N_FRAMES` in main config

## License

Part of the VisionAssist AI Smart Glasses project.

---

**Created by VisionAssist AI Team**
